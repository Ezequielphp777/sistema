<nav class="navbar navbar-default navbar-static-top navbar-inverse" role="navigation"
            style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span> <span
                        class="icon-bar"></span> <span class="icon-bar"></span> <span
                        class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Sistema de control de estudiantes "C.E.I. Francisco Ferrer"</a>

            </div>
                         <div class="navbar-default sidebar"  role="navigation">
                <div class="sidebar-nav navbar-collapse ">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="#"><i class="glyphicon glyphicon-book fa-fw"></i> Cursos<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add-course.php">Agregar curso</a>
                                </li>
                                <li>
                                    <a href="view-course.php">Ver cursos</a>
                                </li>
                            </ul>
                            </li>
                
                 <li>
                            <a href="#"><i class="glyphicon glyphicon-bookmark fa-fw"></i>Tema<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add-subject.php">Agregar Tema</a>
                                </li>
                                <li>
                                    <a href="view-subject.php">Ver Temas</a>
                                </li>
                            </ul>
                           
                        </li>
                        
                   <li>
                            <a href="register.php"><i class="glyphicon glyphicon-file fa-fw"></i>Registrar</a>
                  </li>     
                                            
                   <li>
                            <a href="view.php"><i class="glyphicon glyphicon-education fa-fw"></i>Ver Estudiantes</a>
                  </li>      
                   <li>
                            <a href="logout.php"><i class="glyphicon glyphicon-log-in fa-fw"></i>Salir</a>
                  </li>
                  </ul>                       
                </div>
               
            </div>
            
        </nav>